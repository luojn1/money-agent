"""Expand seed knowledge depth for glossary, rules, cases, and regulations."""

from __future__ import annotations

import csv
import json
import re
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
SEED = ROOT / "knowledge" / "seed_data"
TODAY = "2026-07-09"


def load(folder: str) -> list[dict[str, Any]]:
    return json.loads((SEED / folder / f"{folder}.json").read_text(encoding="utf-8"))


def sql_value(value: Any) -> str:
    if value is None:
        return "NULL"
    if isinstance(value, (int, float)):
        return str(value)
    if isinstance(value, (dict, list)):
        value = json.dumps(value, ensure_ascii=False)
    return "'" + str(value).replace("'", "''") + "'"


def write_dataset(folder: str, table: str, rows: list[dict[str, Any]], columns: list[str]) -> None:
    target = SEED / folder
    target.mkdir(parents=True, exist_ok=True)
    (target / f"{folder}.json").write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8")
    with (target / f"{folder}.csv").open("w", encoding="utf-8-sig", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=columns)
        writer.writeheader()
        for row in rows:
            writer.writerow(
                {
                    column: json.dumps(row.get(column), ensure_ascii=False)
                    if isinstance(row.get(column), (dict, list))
                    else row.get(column, "")
                    for column in columns
                }
            )
    values = ["(" + ", ".join(sql_value(row.get(column, "")) for column in columns) + ")" for row in rows]
    sql = f"INSERT OR REPLACE INTO {table} ({', '.join(columns)}) VALUES\n" + ",\n".join(values) + ";\n"
    (target / f"{folder}.sql").write_text(sql, encoding="utf-8")


def next_id(rows: list[dict[str, Any]], field: str, prefix: str) -> int:
    numbers = []
    for row in rows:
        value = str(row.get(field, ""))
        match = re.match(rf"{re.escape(prefix)}(\d+)$", value)
        if match:
            numbers.append(int(match.group(1)))
    return (max(numbers) if numbers else 0) + 1


def common(source: str = "seed_depth_expansion") -> dict[str, Any]:
    return {
        "version": 1,
        "effective_date": TODAY,
        "expiry_date": "",
        "is_active": 1,
        "source": source,
        "source_url": "",
        "imported_at": TODAY,
        "review_status": "approved",
    }


def append_unique(rows: list[dict[str, Any]], additions: list[dict[str, Any]], key: str, text_key: str) -> None:
    existing_keys = {str(row.get(key)) for row in rows}
    existing_texts = {str(row.get(text_key)) for row in rows}
    for item in additions:
        if str(item.get(key)) in existing_keys or str(item.get(text_key)) in existing_texts:
            continue
        rows.append(item)
        existing_keys.add(str(item.get(key)))
        existing_texts.add(str(item.get(text_key)))


def expand_glossary() -> list[dict[str, Any]]:
    rows = load("financial_glossary")
    start = next_id(rows, "term_id", "TERM")
    specs = [
        ("账单日", "银行每月统计你信用卡消费账单的日期。账单日之后，你会知道这个月要还多少钱。", "credit_card", "账单日是每月 5 日，5 日会生成上个月的消费账单。"),
        ("还款日", "信用卡或贷款最晚要还钱的日期。超过这一天还，可能算逾期。", "credit_card", "还款日是 25 日，26 日才还就可能产生逾期费用。"),
        ("免息期", "刷信用卡后到还款日之间不用付利息的时间。前提通常是全额按时还款。", "credit_card", "本月 1 日消费，25 日前全额还清，就享受了免息期。"),
        ("分期手续费率", "信用卡分期每期要交的手续费比例。它看起来小，但折算成年化可能不低。", "credit_card", "每期手续费率 0.75%，分 12 期后总手续费和真实年化都要算清楚。"),
        ("占用额度", "信用卡分期后，未还完的钱可能继续占用你的信用卡额度。", "credit_card", "额度 2 万，分期 1.2 万后，可用额度可能只剩 8000。"),
        ("全额还款", "在还款日前把当期账单全部还清，通常可以避免循环利息。", "credit_card", "账单 5000 元，还款日前还满 5000 元就是全额还款。"),
        ("滞纳金", "过去常见的逾期费用说法，现在很多场景改称违约金。看到这个词要问清计算方式。", "credit_card", "逾期后账单上出现滞纳金或违约金，都要核对是否重复收费。"),
        ("培训贷", "为支付培训课、考证课、职业课等费用办理的贷款或分期。风险在于课没上完，钱还要还。", "education", "报名编程课时被引导办理 12 期贷款，就是培训贷。"),
        ("服务合同绑定", "培训、医美等服务合同和贷款合同绑在一起。服务出了问题，贷款是否同步处理要写清楚。", "education", "课程取消了，但贷款合同仍要求继续还款，就是绑定风险。"),
        ("履约保证", "机构要求你为履行合同交钱或承担保证责任。重点看不履约的判断标准是否公平。", "education", "退课时机构说你违约，要扣履约保证金。"),
        ("就业承诺", "培训机构承诺推荐就业或保证就业。要看是否写进合同，以及没做到怎么办。", "education", "销售说包就业，但合同只写提供就业指导，维权时就很被动。"),
        ("试听期", "正式开始课程前或初期可以试学的时间。要看试听后不满意能否退费。", "education", "7 天试听不满意可退，比签完就不退更友好。"),
        ("现金价值", "保险退保时按合同计算能拿回的钱，通常不是你已交的全部保费。", "insurance", "交了 2 年保费想退保，能拿回的是现金价值，不一定等于已交保费。"),
        ("退保损失", "退保时拿回的钱少于已交保费，中间差额就是损失。", "insurance", "交了 10000 元，退回 4000 元，损失就是 6000 元。"),
        ("等待期", "保险生效后的一段观察期。等待期内发生某些情况，保险公司可能不赔。", "insurance", "买健康险后 90 天内确诊，可能还在等待期。"),
        ("宽限期", "保费到期后还能补交的一段时间。宽限期内补上，合同通常还能继续。", "insurance", "保费到期忘交，60 天宽限期内补交，保障可能还能延续。"),
        ("犹豫期", "买保险后可以反悔的短时间窗口，通常可低成本退保。", "insurance", "收到保单后 15 天内退保，可能只扣少量工本费。"),
        ("单利", "只按本金计算利息，不把已经产生的利息再拿来计息。", "interest", "借 10000 元，单利年化 10%，一年利息约 1000 元。"),
        ("授信额度", "机构愿意给你的最高可借或可用金额，不代表你已经借了这么多。", "general", "信用卡额度 30000 元，只是最多可用 30000 元。"),
        ("综合融资成本", "把利息、手续费、服务费、担保费等都加起来看的总成本。", "general", "利率不高但服务费很高，综合融资成本仍可能偏高。"),
    ]
    additions = []
    for offset, (term, definition, category, example) in enumerate(specs):
        item = {
            "term_id": f"TERM{start + offset:03d}",
            "term": term,
            "definition": definition,
            "category": category,
            "example": example,
            **common("seed_glossary_depth"),
        }
        additions.append(item)
    append_unique(rows, additions, "term_id", "term")
    return rows


def make_rule(rule_id: str, name: str, category: str, condition: dict[str, Any], level: str, weight: int, basis: str, question: str) -> dict[str, Any]:
    return {
        "rule_id": rule_id,
        "rule_name": name,
        "category": category,
        "condition": condition,
        "risk_level": level,
        "weight": weight,
        "legal_basis": basis,
        "question_to_ask": question,
        "created_at": TODAY,
        "updated_at": TODAY,
        **common("seed_rule_depth"),
    }


def expand_rules() -> list[dict[str, Any]]:
    rows = load("risk_rules")
    start = next_id(rows, "rule_id", "RR")
    specs = [
        ("信用卡最低还款额陷阱", "repayment", {"clauses_contains_any": ["最低还款", "循环利息", "未全额还款"]}, "medium", 14, "《消费者权益保护法》第8条；信用卡业务监管规则", "请银行说明最低还款后从哪一天开始计息、是否按全额或未还部分计息。"),
        ("信用卡账单分期提前还款规则不清", "prepayment", {"clauses_contains_all": ["账单分期", "提前还款"], "clauses_not_contains_any": ["手续费退还", "剩余手续费"]}, "medium", 14, "《民法典》第677条；金融消费者权益保护规则", "请银行说明提前还款时剩余手续费是否退还、如何计算。"),
        ("信用卡分期占用额度未提示", "cost_transparency", {"clauses_contains_any": ["占用额度", "可用额度减少", "额度恢复"]}, "low", 8, "《消费者权益保护法》第8条", "请银行说明分期后占用多少额度、何时恢复额度。"),
        ("信用卡现金分期资金用途限制", "other", {"clauses_contains_all": ["现金分期"], "clauses_contains_any": ["不得用于投资", "不得用于购房", "用途限制"]}, "medium", 10, "信用卡业务监管规则", "请银行说明现金分期资金用途限制和违规后果。"),
        ("信用卡自动分期默认开通", "authorization_privacy", {"clauses_contains_any": ["自动分期", "默认分期", "达到金额自动办理"]}, "medium", 14, "《消费者权益保护法实施条例》第10条", "请银行说明自动分期是否默认开通、如何关闭。"),
        ("教育培训贷诱导性营销", "other", {"clauses_contains_any": ["包就业", "不过包退", "先学后付", "零门槛入学"]}, "high", 20, "《消费者权益保护法》第20条；大学生互联网消费贷款监管通知", "请机构把就业承诺、退费承诺和贷款成本写入合同。"),
        ("教育培训贷贷款主体未充分告知", "cost_transparency", {"clauses_contains_any": ["合作金融机构", "助贷平台", "受托支付"], "clauses_not_contains_any": ["贷款人", "实际放款方"]}, "medium", 14, "金融消费者权益保护规则", "请说明实际放款方、收款方、培训机构三者的责任边界。"),
        ("教育培训贷退课后征信影响未提示", "repayment", {"clauses_contains_all": ["退课", "贷款"], "clauses_not_contains_any": ["征信", "逾期"]}, "medium", 12, "《征信业管理条例》；消费者权益保护规则", "请机构说明退课处理中是否暂停扣款，避免因争议产生征信逾期。"),
        ("教育培训贷学费一次性划转风险", "cost_transparency", {"clauses_contains_any": ["一次性支付培训费", "受托支付至培训机构", "贷款一次性划付"]}, "medium", 12, "金融消费者权益保护规则", "请说明课程未完成时已划转学费如何监管和退回。"),
        ("教育培训贷未设置冷静期", "repayment", {"clauses_contains_any": ["培训贷", "课程分期", "学费分期"], "clauses_not_contains_any": ["冷静期", "试听期", "无理由解除"]}, "low", 8, "消费者权益保护规则", "请机构说明签约后是否有冷静期、试听期或低成本退出路径。"),
        ("自动续费提示不显著", "authorization_privacy", {"clauses_contains_any": ["自动续费", "自动展期"], "clauses_not_contains_any": ["显著提示", "提前提醒", "取消方式"]}, "medium", 14, "《消费者权益保护法实施条例》第10条", "请机构说明续费前如何提醒、在哪里取消。"),
        ("利率浮动风险未明示", "interest_fee", {"clauses_contains_any": ["利率调整", "浮动利率", "按市场变化调整"], "clauses_not_contains_any": ["调整频率", "调整上限"]}, "medium", 14, "中国人民银行公告〔2021〕第3号；《民法典》第496条", "请机构说明利率多久调整一次、最高能涨到多少。"),
        ("担保责任范围模糊", "other", {"clauses_contains_all": ["担保"], "clauses_not_contains_any": ["担保范围", "担保期限", "最高额"]}, "medium", 14, "《民法典》担保制度相关规定", "请机构明确担保覆盖本金、利息、罚息、律师费等哪些项目。"),
        ("投诉渠道缺失", "dispute_resolution", {"clauses_contains_any": ["投诉", "客服", "争议"], "clauses_not_contains_any": ["投诉电话", "处理时限", "监管投诉"]}, "low", 7, "金融消费者权益保护规则", "请机构提供投诉电话、处理时限和升级渠道。"),
        ("费用退还规则缺失", "cost_transparency", {"clauses_contains_any": ["服务费", "管理费", "咨询费"], "clauses_not_contains_any": ["退还", "退费", "返还"]}, "medium", 13, "《消费者权益保护法》第8条", "请机构说明提前结清、退课或取消服务时费用是否退还。"),
        ("保险分期退保损失未提示", "other", {"clauses_contains_any": ["保险分期", "退保", "现金价值"], "clauses_not_contains_any": ["退保损失", "犹豫期"]}, "medium", 15, "保险消费者权益保护相关规则", "请机构说明犹豫期、现金价值和退保可能损失。"),
        ("保险分期等待期未提示", "other", {"clauses_contains_any": ["等待期", "观察期"], "clauses_not_contains_any": ["不承担保险责任", "不予赔付"]}, "low", 8, "保险合同监管规则", "请保险机构说明等待期内哪些情况不赔。"),
        ("保险分期宽限期扣款不清", "repayment", {"clauses_contains_any": ["宽限期", "保费分期", "自动垫交"]}, "medium", 10, "保险合同监管规则", "请说明宽限期内未缴费的保障状态和补缴规则。"),
        ("医美分期项目效果承诺不清", "other", {"clauses_contains_any": ["医美", "效果承诺", "项目效果", "修复"]}, "medium", 12, "《消费者权益保护法》第20条", "请机构说明效果承诺是否写入合同、失败后如何退款或修复。"),
        ("医美分期服务未完成仍扣款", "repayment", {"clauses_contains_any": ["医美分期", "项目取消", "服务未完成", "贷款继续"]}, "high", 20, "《消费者权益保护法》；金融消费者权益保护规则", "请说明医美服务取消或未完成时贷款是否暂停或同步解除。"),
        ("医美分期咨询费退还不清", "cost_transparency", {"clauses_contains_any": ["医美", "咨询费", "设计费"], "clauses_not_contains_any": ["退还", "退费"]}, "medium", 13, "《消费者权益保护法》第8条", "请机构说明咨询费、设计费是否可退以及扣费标准。"),
        ("平台服务费与利息双重计收", "cost_transparency", {"clauses_contains_all": ["服务费", "利息"], "clauses_contains_any": ["平台", "助贷"]}, "medium", 14, "中国人民银行公告〔2021〕第3号", "请机构说明服务费和利息是否重复覆盖同一服务。"),
        ("电子签约身份核验不足", "authorization_privacy", {"clauses_contains_any": ["电子签名", "线上签约"], "clauses_not_contains_any": ["身份核验", "本人确认"]}, "medium", 10, "《电子签名法》；金融消费者权益保护规则", "请平台说明如何确认是本人签约。"),
        ("短信通知收费未明示", "cost_transparency", {"clauses_contains_any": ["短信费", "通知服务费"], "clauses_not_contains_any": ["收费标准"]}, "low", 6, "《消费者权益保护法》第8条", "请机构说明短信通知是否收费、是否可取消。"),
        ("合同文本下载入口缺失", "dispute_resolution", {"clauses_contains_any": ["电子合同", "在线协议"], "clauses_not_contains_any": ["下载", "保存", "发送至邮箱"]}, "low", 7, "《民法典》第496条；电子合同规则", "请平台提供完整合同下载和留存入口。"),
        ("第三方代扣失败责任不清", "authorization_privacy", {"clauses_contains_any": ["代扣失败", "支付机构", "扣款失败"], "clauses_not_contains_any": ["责任", "补救"]}, "medium", 10, "支付结算与消费者权益保护规则", "请说明代扣失败时是否算逾期、如何补救。"),
        ("提前结清证明开具不清", "prepayment", {"clauses_contains_any": ["结清证明", "提前结清"], "clauses_not_contains_any": ["开具", "下载"]}, "low", 6, "金融消费者权益保护规则", "请机构说明结清后如何获取结清证明。"),
        ("借款用途监控过宽", "authorization_privacy", {"clauses_contains_any": ["监控资金用途", "交易流水", "消费记录"], "clauses_not_contains_any": ["范围", "期限"]}, "medium", 12, "《个人信息保护法》；信贷资金用途管理规则", "请机构说明资金用途监控的数据范围和保存期限。"),
    ]
    additions = [make_rule(f"RR{start + i:03d}", *spec) for i, spec in enumerate(specs)]
    append_unique(rows, additions, "rule_id", "rule_name")
    return rows


def make_case(case_id: str, title: str, scenario: str, risk_type: str, description: str, dispute_point: str, user_loss: str, result: str, source_url: str) -> dict[str, Any]:
    fields = common("seed_case_depth")
    fields.pop("source_url", None)
    return {
        "case_id": case_id,
        "title": title,
        "scenario": scenario,
        "risk_type": risk_type,
        "description": description,
        "dispute_point": dispute_point,
        "user_loss": user_loss,
        "handling_result": result,
        "rights_path": "保留合同、账单、扣款记录、宣传页面、录音和客服沟通记录，先书面投诉，再向消协、金融监管或法院/仲裁渠道维权。",
        "source_url": source_url,
        "embedding": "",
        **fields,
    }


def expand_cases() -> list[dict[str, Any]]:
    rows = load("cases")
    start = next_id(rows, "case_id", "CASE")
    specs = [
        ("信用卡免息分期总手续费争议", "信用卡分期", "interest_fee", "用户看到“免息分期”后办理 12 期，账单显示每期手续费，折算真实年化后明显高于预期。", "免息宣传是否充分披露手续费和真实年化。", "用户低估总成本，提前结清也未减少费用。", "银行补充提供费用明细，用户重新选择还款方式。"),
        ("信用卡最低还款循环利息累积", "信用卡分期", "repayment", "用户连续几个月只还最低还款，未意识到剩余本金持续产生循环利息。", "最低还款提示是否足够清楚。", "账单越滚越大，还款压力增加。", "银行解释计息规则，用户申请分期或一次性结清。"),
        ("账单分期提前还款手续费不退", "信用卡分期", "prepayment", "用户提前还清账单分期，银行仍按协议收取剩余手续费。", "提前结清时剩余手续费是否应退还。", "用户提前还款未能节省费用。", "经协商后银行按规则出具费用说明。"),
        ("现金分期资金用途限制争议", "信用卡分期", "other", "用户将现金分期资金用于合同禁止用途，银行要求提前结清。", "用途限制是否显著提示。", "用户被要求提前还款并承担费用。", "银行补充说明资金用途规则。"),
        ("信用卡自动分期默认开通争议", "信用卡分期", "authorization_privacy", "用户消费达到一定金额后被自动分期，认为开通前未充分确认。", "自动分期是否取得明确同意。", "用户承担非预期手续费。", "银行协助取消自动分期并退还部分费用。"),
        ("信用卡额度占用导致支付失败", "信用卡分期", "cost_transparency", "用户办理大额分期后额度长期被占用，后续正常消费失败。", "分期占用额度是否提前提示。", "用户资金安排受影响。", "银行解释额度恢复规则。"),
        ("信用卡分期费率页面展示不完整", "信用卡分期", "cost_transparency", "办理页面只显示每期金额，未显示总手续费和折算年化。", "费用披露是否完整。", "用户误判分期成本。", "银行补充披露完整费率。"),
        ("信用卡逾期违约金和利息叠加", "信用卡分期", "overdue", "用户分期逾期后同时产生违约金、利息和循环利息。", "逾期收费项目是否重复或过高。", "逾期金额快速增加。", "用户申请减免部分费用并调整还款计划。"),
        ("信用卡分期营销短信误导", "信用卡分期", "interest_fee", "营销短信强调低月供，未提示手续费和真实年化。", "营销信息是否充分、真实。", "用户被低月供吸引后承担额外成本。", "银行补充说明并优化营销话术。"),
        ("信用卡账单日还款日理解错误", "信用卡分期", "repayment", "用户混淆账单日和还款日，导致误以为未到还款期限。", "还款时间提示是否清楚。", "产生逾期和征信压力。", "银行协助解释账单周期。"),
        ("培训机构停业贷款仍扣款", "教育培训贷", "repayment", "培训机构突然停业，学员无法上课，但贷款平台继续扣款。", "服务停止后贷款合同是否同步处理。", "学员未获得服务却继续还贷。", "多方调解后调整还款并推动退费。"),
        ("课程质量不符退费难", "教育培训贷", "repayment", "课程内容与宣传不符，用户申请退费时被要求扣除高额服务费。", "课程质量不符是否可解除合同并退费。", "退费周期长且还款继续。", "培训机构减免部分费用并重新协商。"),
        ("诱导大学生办理培训分期", "教育培训贷", "other", "销售人员以就业焦虑和限时优惠诱导大学生办理培训贷款。", "是否充分评估还款能力和真实告知成本。", "学生背负超出能力的贷款。", "投诉后机构解除部分协议。"),
        ("就业承诺未写入合同", "教育培训贷", "other", "销售承诺包就业，但合同只写提供就业指导。", "口头承诺与书面合同不一致。", "用户维权证据不足。", "用户提交聊天记录后协商退费。"),
        ("试听期后退课扣费争议", "教育培训贷", "repayment", "用户试听后不满意申请退课，机构按长期课程扣费。", "试听期和冷静期规则是否明确。", "用户损失课程费和手续费。", "机构按实际课时重新核算。"),
        ("培训贷放款主体不明", "教育培训贷", "cost_transparency", "合同中同时出现培训机构、助贷平台和金融机构，用户不清楚债权人是谁。", "实际贷款主体和收款方是否充分披露。", "维权对象不清，退费处理拖延。", "三方出具责任说明。"),
        ("培训合同与贷款合同互相推诿", "教育培训贷", "other", "退课时培训机构称找贷款机构，贷款机构称服务由培训机构负责。", "服务合同和贷款合同责任边界是否清楚。", "用户继续被扣款。", "调解要求双方共同处理。"),
        ("培训贷征信逾期争议", "教育培训贷", "repayment", "用户因退费争议暂停还款，后发现产生征信逾期记录。", "争议处理期间是否应暂停扣款或征信报送。", "用户信用记录受影响。", "机构协助更正或出具说明。"),
        ("培训贷一次性划转学费", "教育培训贷", "cost_transparency", "贷款一次性划给培训机构，课程未完成时资金已难以追回。", "学费划转和资金监管是否合理。", "用户退费困难。", "协商分期退费。"),
        ("培训贷隐私授权过宽", "教育培训贷", "authorization_privacy", "办理培训贷时要求授权通讯录、定位和人脸信息。", "收集信息是否必要、最小化。", "用户隐私风险增加。", "平台删除非必要信息并调整授权。"),
        ("汽车金融 GPS 服务费争议", "汽车金融", "cost_transparency", "用户办理车贷时被收取 GPS 服务费，但合同未说明服务内容和退费规则。", "GPS 费用是否充分披露。", "用户承担额外费用。", "机构退还部分费用。"),
        ("医美分期项目失败仍还款", "医美分期", "repayment", "医美项目未达到承诺效果，用户要求停止还款被拒。", "服务失败后贷款是否同步处理。", "用户继续还款并承担修复费用。", "机构协商退费或补做服务。"),
        ("保险分期退保损失争议", "保险分期", "other", "用户用分期方式缴纳保费，退保时发现现金价值远低于已交金额。", "退保损失是否充分提示。", "用户承担退保损失和分期费用。", "保险机构补充说明并协商处理。"),
        ("互联网平台会员费搭售", "平台消费贷", "other", "平台贷款时默认勾选会员权益包，用户事后发现被扣会员费。", "会员服务是否自愿购买。", "用户承担非必要费用。", "平台取消会员并退费。"),
        ("租房贷退租后仍扣款", "租赁贷", "repayment", "用户提前退租后，租金分期平台仍按原计划扣款。", "租赁合同解除后贷款是否同步处理。", "用户双重支付租金或分期。", "平台与租赁公司共同调整账单。"),
    ]
    additions = [
        make_case(
            f"CASE{start + i:03d}",
            title,
            scenario,
            risk_type,
            description,
            dispute_point,
            user_loss,
            result,
            f"https://example.com/consumer-finance-cases/depth-{start + i:03d}",
        )
        for i, (title, scenario, risk_type, description, dispute_point, user_loss, result) in enumerate(specs)
    ]
    append_unique(rows, additions, "case_id", "title")
    return rows


def make_reg(reg_id: str, title: str, body: str, issue: str, effective: str, summary: str, keywords: str, scenario: str, url: str = "") -> dict[str, Any]:
    fields = common("seed_regulation_depth")
    fields.pop("source_url", None)
    return {
        "regulation_id": reg_id,
        "title": title,
        "issuing_body": body,
        "issue_date": issue,
        "effective_date": effective,
        "status": "有效",
        "summary": summary,
        "full_text": summary,
        "keywords": keywords,
        "source_url": url,
        "applicable_scenarios": scenario,
        **fields,
    }


def expand_regulations() -> list[dict[str, Any]]:
    rows = load("legal_regulations")
    start = next_id(rows, "regulation_id", "LAW")
    specs = [
        ("《商业银行信用卡业务监督管理办法》- 信息披露", "原中国银监会", "2011-01-13", "2011-01-13", "要求商业银行规范信用卡业务营销、信息披露、风险提示和消费者保护。", "信用卡,信息披露,分期手续费", "信用卡分期"),
        ("《商业银行信用卡业务监督管理办法》- 分期业务管理", "原中国银监会", "2011-01-13", "2011-01-13", "信用卡分期应清晰披露收费项目、收费标准和还款安排。", "信用卡分期,手续费,还款", "信用卡分期"),
        ("《商业银行信用卡业务监督管理办法》- 催收管理", "原中国银监会", "2011-01-13", "2011-01-13", "信用卡催收应依法合规，不得不当披露持卡人信息。", "信用卡,催收,个人信息", "信用卡逾期"),
        ("《银行卡业务管理办法》- 银行卡收费", "中国人民银行", "1999-01-05", "1999-03-01", "银行卡业务收费和服务规则应依法明示，保护持卡人知情权。", "银行卡,收费,持卡人", "信用卡分期"),
        ("《银行卡业务管理办法》- 持卡人权益", "中国人民银行", "1999-01-05", "1999-03-01", "银行卡业务应规范发卡、交易、计息和争议处理。", "银行卡,争议处理,计息", "信用卡"),
        ("《关于进一步规范大学生互联网消费贷款监督管理工作的通知》", "原银保监会等部门", "2021-03-17", "2021-03-17", "规范大学生互联网消费贷款，要求加强营销管理、资质审核、风险提示和合作机构管理。", "大学生,互联网消费贷款,培训贷", "教育培训贷"),
        ("《关于进一步规范大学生互联网消费贷款监督管理工作的通知》- 营销约束", "原银保监会等部门", "2021-03-17", "2021-03-17", "不得针对大学生群体进行诱导性、过度化互联网消费贷款营销。", "大学生,诱导营销,消费贷款", "教育培训贷"),
        ("《关于进一步规范大学生互联网消费贷款监督管理工作的通知》- 合作机构管理", "原银保监会等部门", "2021-03-17", "2021-03-17", "金融机构应加强合作机构管理，不得将核心风控外包。", "合作机构,助贷,风控", "教育培训贷"),
        ("《国务院办公厅关于加强金融消费者权益保护工作的指导意见》", "国务院办公厅", "2015-11-04", "2015-11-04", "强调保障金融消费者知情权、自主选择权、公平交易权、信息安全权等基本权利。", "金融消费者,知情权,自主选择权", "通用"),
        ("《银行保险机构消费者权益保护管理办法》- 知情权", "原银保监会", "2022-12-26", "2023-03-01", "银行保险机构应以显著方式披露产品和服务重要信息。", "银行保险,知情权,显著提示", "通用"),
        ("《银行保险机构消费者权益保护管理办法》- 禁止强制搭售", "原银保监会", "2022-12-26", "2023-03-01", "银行保险机构不得强制搭售产品或服务，不得误导消费者。", "搭售,误导销售,自主选择", "通用"),
        ("《金融消费者权益保护实施办法》- 营销宣传", "中国人民银行", "2020-09-15", "2020-11-01", "金融营销宣传应真实、准确，不得欺诈、隐瞒或误导。", "营销宣传,误导,金融消费者", "通用"),
        ("《金融消费者权益保护实施办法》- 金融信息保护", "中国人民银行", "2020-09-15", "2020-11-01", "金融机构处理消费者金融信息应遵循合法、正当、必要原则。", "个人金融信息,授权,共享", "授权隐私"),
        ("《个人信息保护法》- 单独同意", "全国人大常委会", "2021-08-20", "2021-11-01", "处理敏感个人信息、向第三方提供个人信息等场景通常需要取得单独同意。", "个人信息,单独同意,敏感信息", "授权隐私"),
        ("《电子签名法》- 可靠电子签名", "全国人大常委会", "2019-04-23", "2019-04-23", "可靠电子签名与手写签名或盖章具有同等法律效力。", "电子签名,线上签约,身份核验", "电子合同"),
        ("《互联网贷款管理暂行办法》- 合作机构", "原银保监会", "2020-07-12", "2020-07-17", "商业银行应加强互联网贷款合作机构管理和消费者权益保护。", "互联网贷款,合作机构,消费者保护", "平台消费贷"),
        ("《消费金融公司管理办法》", "国家金融监督管理总局", "2024-03-18", "2024-04-18", "规范消费金融公司经营行为、风险管理和消费者权益保护。", "消费金融公司,消费者保护,贷款", "消费贷"),
        ("《保险销售行为管理办法》", "国家金融监督管理总局", "2023-09-20", "2024-03-01", "规范保险销售前、中、后行为，强化适当性和信息披露。", "保险销售,信息披露,退保", "保险分期"),
        ("《互联网广告管理办法》", "国家市场监督管理总局", "2023-02-25", "2023-05-01", "规范互联网广告活动，要求广告内容真实、合法，不得欺骗误导消费者。", "互联网广告,营销宣传,误导", "信用卡分期,教育培训贷,医美分期"),
    ]
    additions = [
        make_reg(f"LAW{start + i:03d}", *spec)
        for i, spec in enumerate(specs)
    ]
    append_unique(rows, additions, "regulation_id", "title")
    return rows


def update_manifest(counts: dict[str, int]) -> None:
    path = SEED / "manifest.json"
    manifest = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {"counts": {}}
    manifest["generatedAt"] = TODAY
    manifest.setdefault("counts", {}).update(counts)
    manifest["note"] = "Expanded depth for glossary, risk rules, cases, and regulations; includes credit-card installment, education training loan, insurance and medical-beauty scenes."
    path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")


def main() -> None:
    glossary = expand_glossary()
    rules = expand_rules()
    cases = expand_cases()
    regulations = expand_regulations()

    write_dataset("financial_glossary", "financial_glossary", glossary, list(glossary[0].keys()))
    write_dataset("risk_rules", "risk_rules", rules, list(rules[0].keys()))
    write_dataset("cases", "cases", cases, list(cases[0].keys()))
    write_dataset("legal_regulations", "legal_regulations", regulations, list(regulations[0].keys()))

    update_manifest(
        {
            "financial_glossary": len(glossary),
            "risk_rules": len(rules),
            "cases": len(cases),
            "legal_regulations": len(regulations),
        }
    )
    print(
        json.dumps(
            {
                "financial_glossary": len(glossary),
                "risk_rules": len(rules),
                "cases": len(cases),
                "legal_regulations": len(regulations),
            },
            ensure_ascii=False,
        )
    )


if __name__ == "__main__":
    main()
