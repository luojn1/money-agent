"""Refresh scenario expansion seed data with readable UTF-8 Chinese content."""

from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "knowledge" / "seed_data"
TODAY = "2026-07-09"


def sql_value(value: Any) -> str:
    if value is None:
        return "NULL"
    if isinstance(value, (int, float)):
        return str(value)
    if isinstance(value, (dict, list)):
        value = json.dumps(value, ensure_ascii=False)
    return "'" + str(value).replace("'", "''") + "'"


def write_dataset(folder: str, table: str, rows: list[dict[str, Any]], columns: list[str]) -> None:
    target = OUT / folder
    target.mkdir(parents=True, exist_ok=True)
    (target / f"{folder}.json").write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8")

    with (target / f"{folder}.csv").open("w", encoding="utf-8-sig", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=columns)
        writer.writeheader()
        for row in rows:
            writer.writerow(
                {
                    column: json.dumps(row.get(column), ensure_ascii=False)
                    if isinstance(row.get(column), (dict, list))
                    else row.get(column, "")
                    for column in columns
                }
            )

    values = []
    for row in rows:
        values.append("(" + ", ".join(sql_value(row.get(column, "")) for column in columns) + ")")
    sql = f"INSERT OR REPLACE INTO {table} ({', '.join(columns)}) VALUES\n" + ",\n".join(values) + ";\n"
    (target / f"{folder}.sql").write_text(sql, encoding="utf-8")


def dynamic_fields() -> dict[str, Any]:
    return {
        "version": 1,
        "effective_date": TODAY,
        "expiry_date": "",
        "is_active": 1,
        "source": "seed_scenario_expansion",
        "source_url": "",
        "imported_at": TODAY,
        "review_status": "approved",
    }


def rule(
    rule_id: str,
    name: str,
    category: str,
    condition: dict[str, Any],
    level: str,
    weight: int,
    basis: str,
    question: str,
) -> dict[str, Any]:
    return {
        "rule_id": rule_id,
        "rule_name": name,
        "category": category,
        "condition": condition,
        "risk_level": level,
        "weight": weight,
        "legal_basis": basis,
        "question_to_ask": question,
        "created_at": TODAY,
        "updated_at": TODAY,
        **dynamic_fields(),
    }


def build_rules() -> list[dict[str, Any]]:
    rows = [
        rule("RR001", "费用不透明-存在额外费用", "cost_transparency", {"field": "data.costAnalysis.additionalFees", "operator": ">", "value": 0}, "high", 24, "中国人民银行公告〔2021〕第3号；《民法典》第496条", "请机构逐项列明服务费、管理费、手续费等费用，并说明是否已经计入真实年化。"),
        rule("RR002", "砍头息-到账低于本金", "cost_transparency", {"left": "data.contractSummary.actualReceivedAmount", "operator": "<", "right": "data.contractSummary.loanAmount"}, "high", 25, "《民法典》第670条", "请机构说明为什么实际到账金额低于合同本金，扣除费用是否有合法依据。"),
        rule("RR003", "真实年化偏高", "interest_fee", {"field": "data.costAnalysis.realAnnualRate", "operator": ">", "value": 24}, "high", 25, "中国人民银行公告〔2021〕第3号；金融消费者权益保护规则", "请机构用 IRR 口径说明真实年化，并列出纳入计算的全部费用。"),
        rule("RR004", "真实年化明显高于名义利率", "interest_fee", {"left": "data.costAnalysis.realAnnualRate", "operator": ">", "right": "data.contractSummary.nominalRate", "delta": 10}, "high", 20, "中国人民银行公告〔2021〕第3号", "请机构解释名义利率和真实年化之间差异来自哪些费用或还款方式。"),
        rule("RR005", "提前还款收手续费", "prepayment", {"field": "data.contractSummary.prepaymentRule", "operator": "contains_any", "value": ["手续费", "提前结清费", "违约金"]}, "medium", 15, "《民法典》第677条", "请机构说明提前结清时手续费如何计算，已收费用是否可以退还。"),
        rule("RR006", "提前还款仍收全期利息", "prepayment", {"clauses_contains_any": ["提前还款仍收取全部手续费", "剩余手续费不退", "按全部期数收取手续费", "已收利息不退"]}, "high", 22, "《民法典》第677条", "请机构确认提前还款后是否按实际使用期限计息，剩余手续费是否退还。"),
        rule("RR007", "逾期罚息过高", "overdue", {"field": "data.contractSummary.overdueFee", "operator": "contains_any", "value": ["1.5倍", "150%", "高额违约金", "复利"]}, "medium", 14, "《民法典》第585条；金融消费者权益保护规则", "请机构说明逾期费用上限、计算基数和是否重复计收。"),
        rule("RR008", "自动扣款授权过宽", "authorization_privacy", {"clauses_contains_any": ["自动扣款", "代扣", "委托扣款", "不可撤销授权"]}, "medium", 15, "《消费者权益保护法实施条例》第10条；《个人信息保护法》", "请机构说明自动扣款授权范围、期限、取消方式和扣款失败处理规则。"),
        rule("RR009", "征信授权范围过宽", "authorization_privacy", {"clauses_contains_any": ["征信授权", "报送征信", "查询征信", "共享信用信息"]}, "high", 18, "《征信业管理条例》；《个人信息保护法》", "请机构说明征信查询和报送的目的、范围、期限以及撤回方式。"),
        rule("RR010", "格式条款提示不足", "dispute_resolution", {"clauses_contains_any": ["格式条款", "标准合同", "单方制定"], "clauses_not_contains_any": ["特别提示", "加粗", "显著提示"]}, "medium", 12, "《民法典》第496条", "请机构说明是否已经对重要格式条款进行显著提示和解释。"),
        rule("RR011", "单方变更条款", "dispute_resolution", {"clauses_contains_any": ["有权单方调整", "无需另行通知", "平台可变更", "单方修改"]}, "high", 18, "《民法典》第497条；《消费者权益保护法》第26条", "请机构说明哪些内容可以单方变更，用户是否有拒绝或解除权。"),
        rule("RR012", "捆绑销售保险或服务", "other", {"clauses_contains_any": ["必须购买保险", "保险为放款条件", "会员费", "权益包", "增值服务", "捆绑"]}, "medium", 16, "《消费者权益保护法》第9条", "请机构说明保险或服务是否可自主选择，取消后是否影响贷款审批。"),
        rule("RR013", "担保责任不清", "other", {"clauses_contains_any": ["连带责任", "连带保证", "全部债务", "实现债权费用"]}, "high", 20, "《民法典》担保制度相关规定", "请机构说明担保范围、期限、触发条件以及是否承担连带责任。"),
        rule("RR014", "退费条件苛刻", "repayment", {"clauses_contains_any": ["不予退费", "概不退款", "退费需扣除", "退课扣费"]}, "medium", 15, "《消费者权益保护法》；《民法典》合同解除规则", "请机构说明退费条件、扣费项目和处理时限。"),
        rule("RR015", "服务合同解除但贷款继续", "repayment", {"clauses_contains_any": ["服务解除后贷款仍需偿还", "课程终止贷款继续", "合作商户不承担贷款责任", "服务失败仍需还款"]}, "high", 22, "《消费者权益保护法》；金融消费者权益保护规则", "请机构说明服务失败或退费时贷款合同如何同步处理。"),
        rule("RR016", "信用卡分期手续费率未明示", "interest_fee", {"clauses_contains_all": ["信用卡", "分期"], "clauses_not_contains_any": ["手续费率", "每期费率", "折算年化", "真实年化"]}, "high", 22, "中国人民银行公告〔2021〕第3号；《消费者权益保护法》第8条", "请银行写明每期手续费率、总手续费和折算后的真实年化成本。"),
        rule("RR017", "信用卡提前还款仍收全额手续费", "prepayment", {"clauses_contains_all": ["信用卡", "提前"], "clauses_contains_any": ["剩余手续费不退", "全部手续费", "一次性收取", "不予退还"]}, "high", 22, "《民法典》第677条；金融消费者权益保护规则", "请银行确认提前还清时是否还要支付剩余全部手续费，并给出书面计算方式。"),
        rule("RR018", "信用卡免息宣传但收手续费", "interest_fee", {"clauses_contains_all": ["免息"], "clauses_contains_any": ["信用卡", "账单分期", "消费分期", "手续费", "分期费"]}, "high", 24, "中国人民银行公告〔2021〕第3号；《消费者权益保护法》第8条", "请银行把“免息”对应的手续费折算成真实年化，避免只看零利息。"),
        rule("RR019", "教育培训贷机构跑路后贷款继续", "repayment", {"clauses_contains_any": ["培训机构停止服务仍需还款", "课程无法继续仍需还款", "服务中止贷款继续", "合作机构跑路"]}, "high", 24, "《消费者权益保护法》；《民法典》合同解除规则", "请机构说明培训服务中止、机构跑路或无法上课时，贷款是否暂停、解除或重新协商。"),
        rule("RR020", "教育培训贷课程未完成退费不清", "repayment", {"clauses_contains_all": ["课程"], "clauses_contains_any": ["未完成", "退费", "退课", "扣费", "不予退款"]}, "medium", 18, "《消费者权益保护法》第8条；《民法典》合同解除规则", "请培训机构和贷款机构说明未上完课程时如何退费、扣多少、多久退。"),
        rule("RR021", "教育培训贷与服务合同强绑定", "other", {"clauses_contains_any": ["签署课程合同同时办理贷款", "贷款用于支付培训费", "服务合同与贷款合同不可分割", "培训费分期"]}, "high", 20, "《消费者权益保护法》；金融消费者权益保护规则", "请说明课程服务和贷款合同的责任边界，课程取消时贷款是否同步处理。"),
        rule("RR022", "最低还款导致循环利息", "repayment", {"clauses_contains_any": ["最低还款", "循环利息", "只需还最低"]}, "medium", 12, "《消费者权益保护法》第8条", "请银行说明最低还款后的利息、复利和还款周期。"),
        rule("RR023", "复利或利滚利表述", "interest_fee", {"clauses_contains_any": ["复利", "利滚利", "按月复计"]}, "high", 20, "《民法典》公平原则", "请机构说明是否对利息、罚息再次计息。"),
        rule("RR024", "个人信息共享过宽", "authorization_privacy", {"clauses_contains_any": ["关联公司共享", "合作伙伴共享", "第三方共享"]}, "high", 18, "《个人信息保护法》第23条", "请机构列明共享对象、目的、字段和拒绝方式。"),
        rule("RR025", "敏感个人信息处理", "authorization_privacy", {"clauses_contains_any": ["身份证照片", "人脸识别", "生物识别", "银行卡信息"]}, "high", 20, "《个人信息保护法》第28条、第29条", "请机构说明敏感信息处理是否单独同意。"),
        rule("RR026", "催收联系人披露风险", "overdue", {"clauses_contains_any": ["联系紧急联系人", "通知亲友", "联系单位"]}, "high", 18, "金融催收行为规范", "请机构承诺不得向无关人员披露债务信息。"),
        rule("RR027", "暴力催收或威胁性措施", "overdue", {"clauses_contains_any": ["上门施压", "公开曝光", "威胁", "骚扰"]}, "high", 22, "《个人信息保护法》；金融催收自律规范", "请机构承诺不得骚扰、威胁或向无关人员披露信息。"),
        rule("RR028", "协议管辖不便维权", "dispute_resolution", {"clauses_contains_any": ["贷款人所在地法院", "平台所在地法院", "仲裁委员会"]}, "low", 8, "民事诉讼法协议管辖规则", "请机构说明争议解决地点和维权成本。"),
        rule("RR029", "自动续费提示不足", "authorization_privacy", {"clauses_contains_any": ["自动续费", "自动展期"], "clauses_not_contains_any": ["提前提醒", "取消方式"]}, "medium", 14, "《消费者权益保护法实施条例》第10条", "请机构说明续费前提醒方式和取消入口。"),
        rule("RR030", "费用名称模糊", "cost_transparency", {"clauses_contains_any": ["其他费用", "相关费用", "综合费用", "平台费用"]}, "medium", 12, "《民法典》第496条；《消费者权益保护法》第8条", "请机构逐项解释费用名称、金额、收取时间和退费条件。"),
    ]
    return rows


def case_row(
    case_id: str,
    title: str,
    scenario: str,
    risk_type: str,
    description: str,
    dispute_point: str,
    user_loss: str,
    result: str,
    url: str,
) -> dict[str, Any]:
    return {
        "case_id": case_id,
        "title": title,
        "scenario": scenario,
        "risk_type": risk_type,
        "description": description,
        "dispute_point": dispute_point,
        "user_loss": user_loss,
        "handling_result": result,
        "rights_path": "保留合同、扣款记录、宣传页面、客服沟通和投诉记录，先向机构书面投诉，再向消协、金融监管或法院/仲裁渠道维权。",
        "source_url": url,
        "embedding": "",
        **dynamic_fields(),
    }


def build_cases() -> list[dict[str, Any]]:
    return [
        case_row("CASE001", "信用卡分期“免息”实际手续费率畸高", "信用卡分期", "interest_fee", "用户办理信用卡账单分期时看到“免息”宣传，但每期另收手续费，折算真实年化明显高于直观理解。", "“免息”宣传是否充分披露手续费和折算年化成本。", "用户误以为没有成本，实际支付较高分期手续费。", "银行补充披露费率口径，用户重新评估是否提前结清或继续分期。", "https://example.com/cases/credit-card-free-interest-fee"),
        case_row("CASE002", "信用卡提前还款仍需全额手续费", "信用卡分期", "prepayment", "用户提前还清信用卡分期本金，但银行仍要求支付剩余期数手续费或不退已收手续费。", "提前还款后剩余手续费是否仍应全额收取。", "用户提前还款未能减少费用，资金安排落空。", "经协商后银行解释合同规则，部分费用按账单规则调整。", "https://example.com/cases/credit-card-prepayment-fee"),
        case_row("CASE003", "最低还款额循环利息纠纷", "信用卡分期", "repayment", "用户长期只还最低还款额，以为没有逾期，却持续产生循环利息和复利感知落差。", "最低还款是否充分提示循环利息和长期成本。", "用户债务周期拉长，累计利息增加。", "银行提供账单明细，用户调整还款计划并申请费用解释。", "https://example.com/cases/credit-card-minimum-payment"),
        case_row("CASE004", "账单分期手续费率披露不足", "信用卡分期", "cost_transparency", "账单分期页面突出月供较低，但未醒目标注每期手续费率、总手续费和真实年化。", "分期手续费披露是否足够醒目、完整。", "用户低估分期成本。", "经投诉后机构补充披露总费用和年化口径。", "https://example.com/cases/credit-card-fee-disclosure"),
        case_row("CASE005", "培训机构跑路学员仍需还贷", "教育培训贷", "repayment", "用户报名职业培训时被引导办理贷款，培训机构停课或失联后，贷款机构仍继续扣款。", "培训服务无法履行后贷款合同是否应同步暂停或协商处理。", "用户未获得课程服务却继续背负贷款和征信压力。", "经多方调解，培训机构、贷款机构协商退款或调整还款。", "https://example.com/cases/training-provider-closed-loan"),
        case_row("CASE006", "课程质量不符退费困难", "教育培训贷", "repayment", "课程内容、师资或就业承诺与宣传不符，用户申请退课退费，但合同设置高额扣费。", "课程未完成或质量不符时退费条件是否公平。", "用户支付培训费和贷款利息，退费周期长。", "消费者投诉后，机构减免部分费用并重新确认还款计划。", "https://example.com/cases/training-refund-dispute"),
        case_row("CASE007", "诱导性营销办理培训贷款", "教育培训贷", "authorization_privacy", "销售人员强调“先学习后付款”“包就业”，诱导用户快速签署课程合同和贷款协议。", "营销宣传是否误导，贷款办理是否充分告知。", "用户在未充分理解贷款成本的情况下背负分期债务。", "经投诉后机构补充说明费用，用户要求解除合同或调整还款。", "https://example.com/cases/training-loan-misleading-sales"),
        case_row("CASE008", "教育分期服务合同与贷款合同强绑定", "教育培训贷", "other", "课程合同写明服务由培训机构提供，贷款合同由金融机构放款，发生退课时双方互相推诿。", "服务合同解除后贷款合同如何衔接。", "用户退课难、贷款仍扣款，维权对象不清。", "调解要求双方共同出具退费和还款衔接方案。", "https://example.com/cases/training-service-loan-link"),
        case_row("CASE009", "医美分期零利息但服务费另收", "医美分期", "cost_transparency", "医美机构宣传零利息分期，但合同另列咨询费、服务费或平台费。", "费用是否充分披露并计入真实成本。", "用户实际承担费用高于宣传。", "机构补充披露费用并协商部分退费。", "https://example.com/cases/medical-installment-fee"),
        case_row("CASE010", "消费贷到账金额低于合同本金", "消费贷", "cost_transparency", "合同本金为 10000 元，实际到账 9500 元，差额以服务费名义预先扣除。", "是否存在砍头息或变相预扣费用。", "真实年化成本上升。", "要求机构说明扣费依据并重新核算年化。", "https://example.com/cases/consumer-loan-deducted-fee"),
        case_row("CASE011", "自动扣款授权取消困难", "消费贷", "authorization_privacy", "用户想解绑银行卡或取消代扣，但合同写明授权不可撤销或流程不清。", "自动扣款授权范围和取消路径是否清楚。", "可能出现重复扣款或资金安排冲突。", "机构提供取消路径并修正扣款安排。", "https://example.com/cases/auto-debit-cancel"),
        case_row("CASE012", "担保人承担连带责任争议", "担保合同", "other", "担保人未充分理解连带责任，借款人逾期后被要求承担全部债务。", "担保责任范围、期限和触发条件是否充分提示。", "担保人可能承担本金、利息、罚息和实现债权费用。", "法院或调解中重点审查担保条款提示说明。", "https://example.com/cases/joint-guarantee"),
    ]


def glossary_row(term_id: str, term: str, definition: str, category: str, example: str) -> dict[str, Any]:
    fields = dynamic_fields()
    fields["source"] = "seed_plain_language"
    return {
        "term_id": term_id,
        "term": term,
        "definition": definition,
        "category": category,
        "example": example,
        **fields,
    }


def build_glossary() -> list[dict[str, Any]]:
    data = [
        ("TERM001", "等额本息", "每个月还的钱差不多一样。前期还的钱里利息多、本金少，后期本金才还得更多。", "repayment", "比如借 12000 元分 12 期，每月都还约 1050 元，看起来稳定，但前几个月主要是在付利息。"),
        ("TERM002", "等额本金", "每个月还的本金一样，但利息会越来越少，所以一开始月供高，后面慢慢降低。", "repayment", "比如每月固定还 1000 元本金，第一个月利息多，最后几个月利息少。"),
        ("TERM003", "等本等息", "每个月固定还一部分本金，再固定交一笔利息或手续费。看起来费率低，但真实年化可能更高。", "interest", "比如每月还 1000 元本金加 100 元手续费，即使本金越还越少，手续费仍按原来收。"),
        ("TERM004", "IRR", "一种把每次到账和每次还款都算进去的真实成本算法。它比只看利率更接近你实际花了多少钱。", "interest", "合同写年利率 12%，但扣了服务费后，用 IRR 算出来可能接近 23%。"),
        ("TERM005", "APR", "把借钱成本换算成年化后的说法。要注意它有没有把手续费、服务费一起算进去。", "interest", "页面写 APR 10%，但如果不含手续费，你实际承担的成本可能更高。"),
        ("TERM006", "砍头息", "借款还没到你手里，就先扣掉一笔利息或费用。合同本金看着高，实际到手更少。", "cost", "合同写借 10000 元，到账只有 9500 元，少的 500 元就是需要重点核实的预扣费用。"),
        ("TERM007", "服务费", "除了利息之外，机构以“服务”为名收的钱。关键要看服务是什么、多少钱、能不能退。", "cost", "贷款到账时扣 500 元服务费，真实借钱成本会被抬高。"),
        ("TERM008", "管理费", "机构以账户管理、贷后管理等名义收的钱。它本质上也是借钱成本的一部分。", "cost", "每月除了还款还要交 20 元账户管理费，算真实年化时不能漏掉。"),
        ("TERM009", "担保费", "为了找担保公司或保证服务而收的钱。要确认是不是必须买、能不能取消。", "guarantee", "贷款前被要求交 300 元担保费，否则不能放款。"),
        ("TERM010", "保证金", "先交一笔钱作为履约保证。重点看什么时候退、什么情况下不退。", "guarantee", "培训分期要求先交 1000 元保证金，退课时却说要扣掉。"),
        ("TERM011", "连带责任", "别人不还钱时，你可能被直接要求还全部钱，不只是帮忙提醒。", "guarantee", "你给朋友做连带保证，朋友逾期后，机构可以直接找你还款。"),
        ("TERM012", "保证期间", "担保人需要承担担保责任的时间范围。过了这个时间，责任可能会变化。", "guarantee", "合同写主债务到期后三年内都可以要求担保人承担责任。"),
        ("TERM013", "提前结清", "还没到合同最后一期，你一次性把剩下的钱还完。", "prepayment", "原本分 12 期，你第 6 期想把剩余本金一次还清。"),
        ("TERM014", "提前还款违约金", "你提前还钱时，机构额外收的一笔钱。它可能抵消你提前还款省下的利息。", "prepayment", "提前结清要按剩余本金 2% 收费，省下的利息可能还不够交这笔钱。"),
        ("TERM015", "逾期罚息", "超过还款日后，机构额外加收的利息。", "overdue", "本来年化 12%，逾期后按 1.5 倍计收罚息。"),
        ("TERM016", "违约金", "合同约定你违约时要赔的一笔钱。要看计算方式和上限是否清楚。", "overdue", "逾期一天除了罚息，还要按未还金额收违约金。"),
        ("TERM017", "复利", "利息没有还清时，又把利息当本金继续算利息，也就是“利息再生利息”。", "interest", "这个月欠的利息没还，下个月这部分利息也开始产生利息。"),
        ("TERM018", "循环利息", "信用卡没有全额还清时，剩余欠款继续产生的利息。", "credit_card", "账单 10000 元只还最低 1000 元，剩下 9000 元会继续产生循环利息。"),
        ("TERM019", "最低还款", "信用卡账单可以先还一小部分，避免逾期，但剩下的钱会继续算利息。", "credit_card", "本月最低还款 1000 元，不代表剩下 9000 元免费延期。"),
        ("TERM020", "自动扣款", "你授权机构到期直接从银行卡里扣钱。重点看能不能取消、扣错怎么办。", "authorization", "每月还款日系统自动从绑定银行卡扣 940 元。"),
        ("TERM021", "自动续费", "服务到期后自动延长并扣钱。要看续费前是否提醒、在哪里取消。", "authorization", "会员到期后没有手动确认，平台又自动扣了一年费用。"),
        ("TERM022", "征信授权", "你同意机构查询或上报你的信用记录。逾期可能影响以后贷款、信用卡。", "privacy", "贷款审批会查征信，逾期记录可能被报送到征信系统。"),
        ("TERM023", "敏感个人信息", "身份证、人脸、银行卡、定位等比较隐私的信息，被滥用后风险更大。", "privacy", "上传身份证照片和人脸识别信息，需要知道用途和保存多久。"),
        ("TERM024", "格式条款", "机构提前写好的标准合同，你通常只能接受或拒绝，不能逐条谈。", "contract", "点击“同意协议”里的大段标准条款，就是常见格式条款。"),
        ("TERM025", "免责条款", "合同里说某些情况机构不负责的条款。要看是否把本该承担的责任也免掉了。", "contract", "平台写“服务中断概不负责”，但这可能影响你的维权。"),
        ("TERM026", "协议管辖", "合同约定出纠纷去哪里起诉或仲裁。地点太远会增加维权成本。", "contract", "你在成都，合同却要求去平台所在地法院处理纠纷。"),
        ("TERM027", "捆绑销售", "借钱时被要求一起买保险、会员、服务包等。重点看是否可以拒绝。", "sales", "不买保险就不给贷款，可能属于捆绑销售风险。"),
        ("TERM028", "冷静期", "签约后给你一段反悔时间，可以取消或解除。", "exit", "培训课报名后 7 天内可无理由取消，这 7 天就是冷静期。"),
        ("TERM029", "退保现金价值", "长期保险退保时能拿回的钱，通常比已交保费少。", "insurance", "交了 10000 元保费，一年后退保可能只退几千元现金价值。"),
        ("TERM030", "融资租赁", "表面像租东西，实际常用于分期买车等。没还完前资产所有权和处置规则要看合同。", "auto", "汽车融资租赁中，车可能先登记在租赁公司名下。"),
        ("TERM031", "LPR", "贷款市场报价利率，可理解为市场上的贷款参考价之一。很多利率会拿它作对比。", "interest", "1 年期 LPR 如果是 3%，年化 24% 就明显高出很多。"),
        ("TERM032", "真实年化", "把利息、手续费、服务费和还款时间都算进去后的真实年成本。", "interest", "宣传年化 12%，但加入服务费后真实年化可能变成 23%。"),
    ]
    return [glossary_row(*row) for row in data]


def update_manifest(counts: dict[str, int]) -> None:
    manifest_path = OUT / "manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8")) if manifest_path.exists() else {"counts": {}}
    manifest["generatedAt"] = TODAY
    manifest.setdefault("counts", {}).update(counts)
    manifest["note"] = "Scenario expansion seed data refreshed for plain-language glossary, credit-card installment, and education training loan demos."
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")


def main() -> None:
    rule_columns = [
        "rule_id", "rule_name", "category", "condition", "risk_level", "weight",
        "legal_basis", "question_to_ask", "created_at", "updated_at", "version",
        "effective_date", "expiry_date", "is_active", "source", "source_url",
        "imported_at", "review_status",
    ]
    case_columns = [
        "case_id", "title", "scenario", "risk_type", "description", "dispute_point",
        "user_loss", "handling_result", "rights_path", "source_url", "embedding",
        "version", "effective_date", "expiry_date", "is_active", "source",
        "source_url", "imported_at", "review_status",
    ]
    glossary_columns = [
        "term_id", "term", "definition", "category", "example", "version",
        "effective_date", "expiry_date", "is_active", "source", "source_url",
        "imported_at", "review_status",
    ]

    rules = build_rules()
    cases = build_cases()
    glossary = build_glossary()
    write_dataset("risk_rules", "risk_rules", rules, rule_columns)
    write_dataset("cases", "cases", cases, case_columns)
    write_dataset("financial_glossary", "financial_glossary", glossary, glossary_columns)
    update_manifest({"risk_rules": len(rules), "cases": len(cases), "financial_glossary": len(glossary)})
    print(json.dumps({"risk_rules": len(rules), "cases": len(cases), "financial_glossary": len(glossary)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
