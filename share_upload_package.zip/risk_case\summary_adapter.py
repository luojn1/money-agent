# -*- coding: utf-8 -*-
"""C module adapter for the 30-second summary report.

This file keeps C's responsibility narrow: C only summarizes its own riskItems
into plain-language risk bullets. The final one-page summary is assembled by D
or the backend using B/C/D outputs together.
"""

from __future__ import annotations

from typing import Any


def _short(text: str, limit: int = 20) -> str:
    text = " ".join(str(text or "").replace("\n", " ").split())
    if len(text) <= limit:
        return text
    return text[: limit - 1] + "…"


def _plain_title(risk: dict[str, Any]) -> str:
    title = risk.get("title") or ""
    if any(word in title for word in ["免息", "手续费", "分期手续费"]):
        return "手续费要问清"
    if any(word in title for word in ["费用", "服务费", "管理费", "咨询费"]):
        return "费用要列全"
    if any(word in title for word in ["真实年化", "年化", "利率"]):
        return "实际成本偏高"
    if any(word in title for word in ["提前还款", "提前结清"]):
        return "提前还款有门槛"
    if any(word in title for word in ["最低还款", "循环利息"]):
        return "最低还款别轻信"
    if any(word in title for word in ["自动扣款", "授权"]):
        return "扣款授权要收窄"
    if any(word in title for word in ["培训", "课程", "退课", "退费"]):
        return "退课贷款要写清"
    return _short(title, 14)


def _plain_text(risk: dict[str, Any]) -> str:
    title = risk.get("title") or ""
    if any(word in title for word in ["免息", "手续费", "分期手续费"]):
        return "免息不等于免费"
    if any(word in title for word in ["费用", "服务费", "管理费", "咨询费"]):
        return "有费用没说清"
    if any(word in title for word in ["真实年化", "年化", "利率"]):
        return "实际成本可能更高"
    if any(word in title for word in ["提前还款", "提前结清"]):
        return "提前还也可能收费"
    if any(word in title for word in ["最低还款", "循环利息"]):
        return "少还会继续计息"
    if any(word in title for word in ["自动扣款", "授权"]):
        return "扣款权限可能太大"
    if any(word in title for word in ["培训", "课程", "退课", "退费"]):
        return "退课后还可能还贷"
    return "这条要问清楚"


def build_c_summary_fragments(c_output: dict[str, Any], limit: int = 5) -> dict[str, Any]:
    """Return C-owned summary fragments for backend/D assembly."""
    risk_items = (c_output.get("data") or {}).get("riskItems") or []
    order = {"high": 0, "medium": 1, "low": 2}
    picked = sorted(risk_items, key=lambda item: order.get(item.get("riskLevel"), 3))[:limit]
    return {
        "riskSummary": (c_output.get("data") or {}).get("riskSummary") or {"high": 0, "medium": 0, "low": 0},
        "topRisks": [
            {
                "id": item.get("id"),
                "title": _plain_title(item),
                "plainText": _plain_text(item),
                "level": item.get("riskLevel", "medium"),
                "detailAnchor": f"#risk-{item.get('id')}",
            }
            for item in picked
        ],
    }

